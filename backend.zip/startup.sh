#!/bin/bash

# Start Gunicorn with our app
gunicorn -c gunicorn_conf.py app:app 